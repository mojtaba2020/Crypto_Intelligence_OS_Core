# Phase 0 Status

## Implemented and tested

- Canonical IDs
- UTC normalization
- Strict immutable base contracts
- Structured errors and fingerprints
- Health contracts
- JSON Schema export + drift detection
- Stable Core provider-coupling guard
- Internal Python dependency graph generator
- Unit tests
- CI workflow
- Dependabot configuration

## Deliberately not implemented yet

- Market data provider
- Database
- Model provider adapters
- Agents
- Prediction Ledger persistence
- Backtesting engine
- Risk Engine
- Trading or exchange execution
- API keys or secrets

## Status label

**LOCALLY TESTED FOUNDATION SKELETON — FIRST GITHUB CI RUN REQUIRED**

This label does not mean production-ready. Runtime tests passed locally; the first GitHub CI run
must still pass Ruff and Mypy before this baseline is promoted further.

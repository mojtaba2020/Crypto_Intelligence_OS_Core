# Crypto Intelligence OS — Phase 0 Foundation v0.1

Status: **TESTED FOUNDATION SKELETON**

This package establishes the first executable foundation for Crypto Intelligence OS.
It intentionally contains **no trading**, **no exchange credentials**, **no model API keys**,
and **no autonomous production writes**.

## What is included

- Canonical UTC time helpers
- Provider-neutral ID factory
- Strict base contracts using Pydantic
- Structured error contracts
- Health-state contracts
- Schema generation and drift checking
- Architecture drift guard for the Stable Core
- Static internal dependency graph generator
- Automated tests
- Ruff lint/security checks
- Mypy strict type checks
- GitHub Actions CI
- Dependabot configuration for Python and GitHub Actions

## Local verification

```bash
python -m pip install -e ".[dev]"
python scripts/quality_gate.py
```

## Important boundary

This is a foundation skeleton, not a trading system. Any future capital execution must remain
behind Risk, Security, Human Approval, and a separately validated Execution Gateway.

"""Crypto Intelligence OS core package."""

__version__ = "0.1.0"
